import torch

class Criterion(torch.nn.Module):
    def __call__(self, pred, target):        
        ce_loss = torch.nn.functional.cross_entropy(pred, target, reduction='mean')
        return ce_loss
        
