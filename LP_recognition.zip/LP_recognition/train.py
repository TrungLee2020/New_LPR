import cv2, os, time, sys, platform, tqdm
import torch
import numpy as np
import torchvision
import torch.nn.init as init
from torch.utils.data import DataLoader
from dataset import CLPDataset, collate_fn, Transformer
from hyperparams import Hyperparams as hp
from utils import inverse_norm, load_vocab
from model import Model
from loss import Criterion


use_gpu = torch.cuda.is_available()
_, i2c = load_vocab()

def count_parameters(model):
    return sum(p.numel() for p in model.parameters() if p.requires_grad)

def weight_init(m):
    '''
    Usage:
        model = Model()
        model.apply(weight_init)
    '''
    if isinstance(m, torch.nn.Conv1d):
        init.normal_(m.weight.data)
        if m.bias is not None:
            init.normal_(m.bias.data)
    elif isinstance(m, torch.nn.Conv2d):
        init.xavier_normal_(m.weight.data)
        if m.bias is not None:
            init.normal_(m.bias.data)
    elif isinstance(m, torch.nn.Conv3d):
        init.xavier_normal_(m.weight.data)
        if m.bias is not None:
            init.normal_(m.bias.data)
    elif isinstance(m, torch.nn.ConvTranspose1d):
        init.normal_(m.weight.data)
        if m.bias is not None:
            init.normal_(m.bias.data)
    elif isinstance(m, torch.nn.ConvTranspose2d):
        init.xavier_normal_(m.weight.data)
        if m.bias is not None:
            init.normal_(m.bias.data)
    elif isinstance(m, torch.nn.ConvTranspose3d):
        init.xavier_normal_(m.weight.data)
        if m.bias is not None:
            init.normal_(m.bias.data)
    elif isinstance(m, torch.nn.BatchNorm1d):
        init.normal_(m.weight.data, mean=1, std=0.02)
        if m.bias is not None:
            init.constant_(m.bias.data, 0)
    elif isinstance(m, torch.nn.BatchNorm2d):
        init.normal_(m.weight.data, mean=1, std=0.02)
        if m.bias is not None:
            init.constant_(m.bias.data, 0)
    elif isinstance(m, torch.nn.BatchNorm3d):
        init.normal_(m.weight.data, mean=1, std=0.02)
        if m.bias is not None:
            init.constant_(m.bias.data, 0)
    elif isinstance(m, torch.nn.Linear):
        init.xavier_normal_(m.weight.data)
        if m.bias is not None:
            init.normal_(m.bias.data)
    elif isinstance(m, torch.nn.LSTM):
        for param in m.parameters():
            if len(param.shape) >= 2:
                init.orthogonal_(param.data)
            else:
                init.normal_(param.data)
    elif isinstance(m, torch.nn.LSTMCell):
        for param in m.parameters():
            if len(param.shape) >= 2:
                init.orthogonal_(param.data)
            else:
                init.normal_(param.data)
    elif isinstance(m, torch.nn.GRU):
        for param in m.parameters():
            if len(param.shape) >= 2:
                init.orthogonal_(param.data)
            else:
                init.normal_(param.data)
    elif isinstance(m, torch.nn.GRUCell):
        for param in m.parameters():
            if len(param.shape) >= 2:
                init.orthogonal_(param.data)
            else:
                init.normal_(param.data)

def accuracy(pred, gt):
    pred = np.array(pred)
    gt = np.array(gt)
    correct = (pred == gt).sum()
    return (correct / len(gt)) * 100

def train():
    train_dataset = CLPDataset('./CCPD2020/ccpd_green/train/', Transformer(val=False))
    train_dataloader = DataLoader(train_dataset, batch_size=hp.batch_size, shuffle=True, drop_last=False, num_workers=hp.n_jobs, collate_fn=collate_fn, pin_memory=use_gpu)

    valid_dataset = CLPDataset('./CCPD2020/ccpd_green/val/', Transformer(val=True))
    valid_dataloader = DataLoader(valid_dataset, batch_size=hp.batch_size, shuffle=True, drop_last=False, num_workers=hp.n_jobs, collate_fn=collate_fn, pin_memory=use_gpu)


    model = torch.nn.DataParallel(Model())
    scaler = torch.cuda.amp.GradScaler(enabled=use_gpu)
    model.apply(weight_init)
    if use_gpu:
        model.cuda()
        torch.backends.cudnn.benchmark = True
        torch.backends.cudnn.enabled = True

    criterion = Criterion()
    optimizer = torch.optim.Adadelta(model.parameters(), lr=hp.lr, weight_decay=1e-5)

    print('Number of parameters: ', count_parameters(model))

    curr_epoch = 0
    if os.path.exists(hp.logdir + 'model.pkl'):
        if use_gpu:
            map_location = lambda storage, loc: storage.cuda()
        else:
            map_location = 'cpu'
        ckpt = torch.load(hp.logdir + 'model.pkl', map_location=map_location)
        model.load_state_dict(ckpt['state_dict'])
        optimizer.load_state_dict(ckpt['optimizer_state_dict'])
        curr_epoch = ckpt['global_step']
        print('Restore model')



    for epoch in range(curr_epoch+1, hp.epochs):
        model.train()
        optimizer.zero_grad(set_to_none=True)

        for step, (img_tensor, encoded_tensor, _) in enumerate(train_dataloader):
            start = time.time()

            if use_gpu:
                img_tensor, encoded_tensor = img_tensor.cuda(), encoded_tensor.cuda()

            with torch.cuda.amp.autocast():
                _, output = model(img_tensor)
                loss = criterion(output, encoded_tensor)

            scaler.scale(loss).backward()

            if (step+1) % hp.update == 0 or (step+1) == len(train_dataloader):
                scaler.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=2, norm_type=2)
                scaler.step(optimizer)
                scaler.update()
                optimizer.zero_grad(set_to_none=True)

            end = time.time()
            sys.stdout.write('\rEpoch: %03d, Step: %04d/%d, Loss: %.9f, Time training: %.2f secs' % (epoch, step+1, len(train_dataloader), loss.item(), end-start))

        ckpt_path = hp.logdir + 'model.pkl'
        torch.save({"state_dict": model.state_dict(),
                    "optimizer_state_dict": optimizer.state_dict(),
                    "global_step": epoch}, ckpt_path)

        if epoch % hp.display == 0:
            model.eval()

            pred_texts, gt_texts = [], []
            for img_tensor, _, label in tqdm.tqdm(valid_dataloader):
                if use_gpu:
                    img_tensor = img_tensor.cuda()

                with torch.no_grad(), torch.cuda.amp.autocast():
                    _, output = model(img_tensor)
                
                prob = output.softmax(dim=1)
                max_ind = prob.argmax(dim=1).cpu().numpy().tolist()
                pred_texts += [''.join(list(map(lambda i: i2c[i], e))) for e in max_ind]
                gt_texts += label

            print('Validation accuracy:', accuracy(pred_texts, gt_texts))

if __name__ == '__main__':
    torch.manual_seed(42)
    print('Use GPU: ', use_gpu)
    if use_gpu:
        print('Device name: ', torch.cuda.get_device_name(torch.cuda.current_device()))
    print('Processor: ', platform.processor())
    train()
