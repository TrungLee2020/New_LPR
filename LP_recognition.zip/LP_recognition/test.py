import torch
import os, pylab, cv2
from PIL import Image
import numpy as np
from torch.utils.data import DataLoader
from dataset import CLPDataset, collate_fn, Transformer
from hyperparams import Hyperparams as hp
from model import Model
from utils import load_vocab, inverse_norm

use_gpu = torch.cuda.is_available()
_, i2c = load_vocab()

def normalize(img):
    img = (img - img.min())/(img.max() - img.min())
    return img

def visualize(image, attn_maps, n_pred):
    cm = pylab.cm.get_cmap('jet_r')
    outputs = []

    for i, attn_map in enumerate(attn_maps[0: n_pred]):
        attn_map = normalize(attn_map)
        attn_map = cm(attn_map)
        attn_map = cv2.cvtColor((255 * attn_map).astype('uint8'), cv2.COLOR_RGBA2RGB)
        fused_image = (image * 0.5 + attn_map * 0.5).astype('uint8')
        outputs.append(Image.fromarray(cv2.cvtColor(fused_image, cv2.COLOR_BGR2RGB)))

        cv2.imshow('result', fused_image)
        if cv2.waitKey(1000) & 0xFF == 27:
            break
    outputs[0].save('./result.gif', save_all=True, append_images=outputs[1:], optimize=False, duration=1000, loop=0)


def test():
    val_dataset = CLPDataset('./CCPD2020/ccpd_green/val/', Transformer(val=True))
    val_dataloader = DataLoader(val_dataset, batch_size=1, shuffle=True, drop_last=False, num_workers=1, collate_fn=collate_fn, pin_memory=use_gpu)

    model = torch.nn.DataParallel(Model())
    if use_gpu:
        model.cuda()
        torch.backends.cudnn.benchmark = True
        torch.backends.cudnn.enabled = True

    curr_epoch = 0
    if os.path.exists(hp.logdir + 'model.pkl'):
        if use_gpu:
            map_location = lambda storage, loc: storage.cuda()
        else:
            map_location = 'cpu'
        ckpt = torch.load(hp.logdir + 'model.pkl', map_location=map_location)
        model.load_state_dict(ckpt['state_dict'])
        print('Restore model')


    model.eval()
    for img_tensor, _, label in val_dataloader:
        if use_gpu:
            img_tensor = img_tensor.cuda()

        with torch.no_grad(), torch.cuda.amp.autocast():
            _, output = model(img_tensor)

        prob = output.softmax(dim=1)
        max_ind = prob.argmax(dim=1).cpu().numpy().tolist()
        pred_text = [''.join(list(map(lambda i: i2c[i], e))) for e in max_ind]
        print(pred_text, label)
        

if __name__ == '__main__':
    test()
        