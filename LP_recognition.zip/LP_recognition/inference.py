import time
import numpy as np
from scipy.special import softmax
from torch.utils.data import DataLoader
from openvino.inference_engine import IECore
from dataset import CLPDataset, collate_fn, Transformer
from utils import load_vocab

_, i2c = load_vocab()

def load_infer_model(xml_path):
    bin_path = xml_path[:-3] + 'bin'
    ie = IECore()
    net = ie.read_network(model=xml_path, weights=bin_path)
    exec_net = ie.load_network(network=net, device_name='CPU')
    return exec_net

def sync_inference(exec_net, img_tensor):
    input_key = list(exec_net.input_info.keys())[0]
    output_key = list(exec_net.outputs.keys())[0]
    result = exec_net.infer({input_key: img_tensor})
    return result[output_key]

def infer():
    model_path = './model/model.xml'
    exec_net = load_infer_model(model_path)

    val_dataset = CLPDataset('./CCPD2020/ccpd_green/val/', Transformer(val=True))
    val_dataloader = DataLoader(val_dataset, batch_size=1, shuffle=True, drop_last=False, num_workers=1, collate_fn=collate_fn, pin_memory=False)

    for img_tensor, _, label in val_dataloader:
        start = time.time()
        img_tensor = img_tensor.cpu().numpy()
        output = sync_inference(exec_net, img_tensor=img_tensor)
        prob = softmax(output, axis=1)
        max_ind = np.argmax(prob, axis=1).tolist()
        pred_text = [''.join(list(map(lambda i: i2c[i], e))) for e in max_ind]
        end = time.time()
        print(pred_text, label, end-start)

if __name__ == '__main__':
    infer()