import json
import torch
import torchvision.transforms as transforms
from torch.utils.data import Dataset
from PIL import Image
from hyperparams import Hyperparams as hp
from utils import Resize, LabelEncoding


class CLPDataset(Dataset):
    def __init__(self, root, transform):
        super(CLPDataset, self).__init__()
        self.transform = transform
        self.root = root

        with open(self.root + 'annotations.json') as f:
            data = json.load(f)

        self.data = list(data.items())

    def __getitem__(self, index):
        fname, ann = self.data[index]
        image = Image.open(self.root + fname)
        bbox, label = ann[:4], ann[-1]
        instance, encoded = self.transform(image, bbox, label)

        return instance, encoded, label
    
    def __len__(self):
        return len(self.data)

class Transformer:
    def __init__(self, val=False):
        self.val = val
        self.resize = Resize()
        self.train = transforms.Compose([
            transforms.ColorJitter(brightness=0.5, contrast=0.5, saturation=0.3),
            transforms.ToTensor(),
            transforms.Normalize(mean=hp.mean, std=hp.std)
        ])
        self.valid = transforms.Compose([
            transforms.ToTensor(),
            transforms.Normalize(mean=hp.mean, std=hp.std)
        ])
        self.encoder = LabelEncoding()

    def __call__(self, image, bbox, label):
        instance = image.crop(bbox)
        instance = self.resize(instance)
        if self.val is False:
            instance = self.train(instance)
        else:
            instance = self.valid(instance)
        encoded = torch.as_tensor(self.encoder(label)).long()
        return instance, encoded

def collate_fn(batch):
    image = torch.stack([sample[0] for sample in batch], dim=0)
    encoded = torch.stack([sample[1] for sample in batch], dim=0)
    label = [sample[2] for sample in batch]
    return image, encoded, label

# if __name__ == '__main__':
#     import cv2, tqdm
#     from torch.utils.data import DataLoader
#     from utils import inverse_norm

#     train_dataset = CLPDataset('./CCPD2020/ccpd_green/train/', Transformer(val=False))
#     train_dataloader = DataLoader(train_dataset, batch_size=1, shuffle=False, drop_last=False, num_workers=1, collate_fn=collate_fn, pin_memory=False)

#     for image, encoded, label in tqdm.tqdm(train_dataloader):
#         image = inverse_norm(image[0], mean=hp.mean, std=hp.std)
#         image = (image.permute(1, 2, 0).cpu().numpy() * 255).astype('uint8').copy()
#         image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

#         print(encoded)

#         cv2.imshow('result', image)
#         cv2.waitKey(0)
#         cv2.destroyAllWindows()
