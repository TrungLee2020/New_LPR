import torch
from efficient_net import efficient_net
from hyperparams import Hyperparams as hp
from utils import LayerNorm

class Model(torch.nn.Module):
    def __init__(self, squeeze_ratio=0.25):
        super(Model, self).__init__()
        self.backbone = efficient_net('b0')
        fsize = self._get_fsize()
        self.mid_channels = 256
        n_chars = len(hp.alphabet)

        self.upsample = torch.nn.ModuleList()
        self.pre_fusion = torch.nn.ModuleList()
        self.post = torch.nn.Sequential(
            LayerNorm(norm_dim=(2, 3))
        )
        self.softmax = torch.nn.Softmax(dim=-1)

        for i in range(len(fsize) - 1):
            self.upsample.append(
                torch.nn.Sequential(
                    torch.nn.Upsample(size=fsize[i+1][1:], mode='bilinear', align_corners=False),
                    torch.nn.Conv2d(in_channels=fsize[i][0], out_channels=fsize[i+1][0], kernel_size=3, padding=1, bias=False),
                    torch.nn.BatchNorm2d(num_features=fsize[i+1][0]),
                    torch.nn.LeakyReLU(0.1, inplace=True)
                )
            )

        for i in range(len(fsize)):
            self.pre_fusion.append(
                torch.nn.Sequential(
                    torch.nn.Upsample(size=fsize[-1][1:], mode='bilinear', align_corners=False),
                    torch.nn.Conv2d(in_channels=fsize[i][0], out_channels=self.mid_channels, kernel_size=1, bias=False),
                    torch.nn.BatchNorm2d(num_features=self.mid_channels)
                )
            )

        self.aux_branch = torch.nn.Sequential(
            torch.nn.Conv2d(in_channels=self.mid_channels, out_channels=int(squeeze_ratio * self.mid_channels), kernel_size=3, padding=1, bias=False),
            torch.nn.LeakyReLU(0.1, inplace=True),
            torch.nn.Conv2d(in_channels=int(squeeze_ratio * self.mid_channels), out_channels=self.mid_channels, kernel_size=3, padding=1, bias=False),
            torch.nn.Conv2d(in_channels=self.mid_channels, out_channels=hp.max_sequence_length, kernel_size=1, bias=False),
            LayerNorm(norm_dim=(2, 3))
        )

        self.gen = torch.nn.Sequential(
            torch.nn.Linear(in_features=self.mid_channels, out_features=self.mid_channels),
            torch.nn.Dropout(p=0.25),
            torch.nn.Linear(in_features=self.mid_channels, out_features=n_chars)
        )

    def _get_fsize(self):
        features = self.backbone(torch.rand(1, 3, hp.size[1], hp.size[0]))[::-1][:5]
        return [o.size()[1:] for o in features]

    def forward(self, x):
        features = self.backbone(x)[::-1][:5]
        x = features[0]
        pred_list = [self.pre_fusion[0](x)]

        for i in range(len(features) - 1):
            x = self.upsample[i](x) + features[i+1]
            pred_list.append(self.pre_fusion[i+1](x))

        fused_feat = self.post(torch.stack(pred_list).sum(dim=0))
        aux_out = self.aux_branch(fused_feat)
        b, l, h, w = aux_out.size()
        attn_map = self.softmax(aux_out.reshape(b, l, -1)).reshape(b, l, h, w)
        context = fused_feat.reshape(b, 1, self.mid_channels, h, w) * attn_map.reshape(b, l, 1, h, w)
        context = context.sum(dim=(-2, -1)) # (b, l, c)
        output = self.gen(context)

        return attn_map, output.transpose(1, 2)

# if __name__ == '__main__':
#     import onnx
#     import onnxruntime
#     import time, os

#     use_gpu = torch.cuda.is_available()

#     x = torch.randn(1, 3, 64, 192, requires_grad=True).cuda()
#     model = torch.nn.DataParallel(Model()).cuda()
#     model = model.eval()
#     if os.path.exists(hp.logdir + 'model.pkl'):
#         if use_gpu:
#             map_location = lambda storage, loc: storage.cuda()
#         else:
#             map_location = 'cpu'
#         ckpt = torch.load(hp.logdir + 'model.pkl', map_location=map_location)
#         model.load_state_dict(ckpt['state_dict'])
#         print('Restore model')

#     torch.onnx.export(
#         model.module, x,
#         './model/model.onnx',
#         export_params=True,
#         opset_version=12,
#         do_constant_folding=True,
#         input_names = ['input'],
#         output_names = ['output'],
#         # dynamic_axes={
#         #     'input' : {0 : 'batch_size', 2: 'height', 3: 'width'},
#         #     'output' : {0 : 'batch_size', 2: 'height', 3: 'width'}
#         # }
#     )