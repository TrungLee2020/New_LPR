# pylint: disable=undefined-variable, no-member
import math
import torch
from utils import ConvBlock, SEModule, drop_connect

class MBConvBlock(torch.nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, stride, expand_ratio, se_ratio=None, drop_connect_rate=None, batch_norm_momentum=0.99, batch_norm_epsilon=1e-3):
        super(MBConvBlock, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.stride = stride
        self.drop_connect_rate = drop_connect_rate

        self.id_skip = (drop_connect_rate is not None) and (0 < drop_connect_rate <= 1)
        self.has_se = (se_ratio is not None) and (0 < se_ratio <= 1)
        self._swish = torch.nn.SiLU()

        bn_mom = 1 - batch_norm_momentum
        bn_eps = batch_norm_epsilon
        mid_channels = int(in_channels * expand_ratio)

        # Expansion phase
        self._expand_conv = ConvBlock(
            in_channels=in_channels,
            out_channels=mid_channels,
            kernel_size=1, stride=1, padding=0, groups=1, batch_norm=False, activation=False
        )
        self._bn0 = torch.nn.BatchNorm2d(num_features=mid_channels, momentum=bn_mom, eps=bn_eps)
        # Depthwise convolution phase
        self._depthwise_conv = ConvBlock(
            in_channels=mid_channels,
            out_channels=mid_channels,
            kernel_size=kernel_size, stride=stride, padding=int((kernel_size-1)/2), groups=mid_channels, batch_norm=False, activation=False
        )
        self._bn1 = torch.nn.BatchNorm2d(num_features=mid_channels, momentum=bn_mom, eps=bn_eps)
        # Squeeze and Excitation layer
        if self.has_se:
            num_squeezed_channels = max(1, int(in_channels * se_ratio))
            self._se = SEModule(in_channels=mid_channels, squeeze_channels=num_squeezed_channels, swish=self._swish)
        # Pointwise convolution phase
        self._project_conv = ConvBlock(
            in_channels=mid_channels,
            out_channels=out_channels,
            kernel_size=1, stride=1, padding=0, groups=1, batch_norm=False, activation=False
        )
        self._bn2 = torch.nn.BatchNorm2d(num_features=out_channels, momentum=bn_mom, eps=bn_eps)

        self.shortcut = torch.nn.Sequential()
        if stride != 1 or in_channels != out_channels:
            self.shortcut = torch.nn.Sequential(
                torch.nn.Conv2d(in_channels=in_channels, out_channels=out_channels, kernel_size=1, stride=stride),
                torch.nn.BatchNorm2d(num_features=out_channels)
            )

    def forward(self, inputs):
        x = inputs
        x = self._expand_conv(inputs)
        x = self._bn0(x)
        x = self._swish(x)

        x = self._depthwise_conv(x)
        x = self._bn1(x)
        x = self._swish(x)

        if self.has_se:
            x = self._se(x)

        x = self._project_conv(x)
        x = self._bn2(x)

        if self.id_skip and self.stride == 1 and self.in_channels == self.out_channels:
            x = drop_connect(x, p=self.drop_connect_rate, training=self.training)

        x += self.shortcut(inputs)
        return x


class MBLayer(torch.nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, stride, expand_ratio, se_ratio, drop_connect_rate, num_layers):
        super(MBLayer, self).__init__()
        strides = [stride] + [1]*(num_layers-1)
        layers = []
        for idx, stride in enumerate(strides):
            layers.append(MBConvBlock(in_channels, out_channels, kernel_size, stride, expand_ratio, se_ratio, drop_connect_rate))
            in_channels = out_channels
        self.layers = torch.nn.Sequential(*layers)

    def forward(self, x):
        return self.layers(x)

class EfficientNet(torch.nn.Module):
    def __init__(self, layer_params):
        super(EfficientNet, self).__init__()
        self.layers = torch.nn.ModuleList()
        self.layers.append(
            ConvBlock(
                in_channels=layer_params[0]['in_channels'],
                out_channels=layer_params[0]['out_channels'], 
                kernel_size=layer_params[0]['kernel_size'],
                stride=layer_params[0]['stride'],
                padding=layer_params[0]['padding'],
                groups=layer_params[0]['groups']
            )
        )
        for i in range(1, len(layer_params)):
            self.layers.append(
                MBLayer(
                    in_channels=layer_params[i]['in_channels'],
                    out_channels=layer_params[i]['out_channels'],
                    kernel_size=layer_params[i]['kernel_size'],
                    stride=layer_params[i]['stride'],
                    expand_ratio=layer_params[i]['expand_ratio'],
                    se_ratio=layer_params[i]['se_ratio'],
                    drop_connect_rate=layer_params[i]['drop_connect_rate'],
                    num_layers=layer_params[i]['num_layers']
                )
            )
    def forward(self, x):
        outputs = []
        for layer in self.layers:
            x = layer(x)
            outputs.append(x)
        return outputs

def efficient_net(mode='b0'):
    coefficient_params = {
        'b0': (1.0, 1.0),
        'b1': (1.0, 1.1),
        'b2': (1.1, 1.2),
        'b3': (1.2, 1.4),
        'b4': (1.4, 1.8),
        'b5': (1.6, 2.2),
    }
    width_coefficient = coefficient_params[mode][0]
    depth_coefficient = coefficient_params[mode][1]
    layer_params = [
        {'in_channels': 3, 'out_channels': round_filters(32, width_coefficient), 'kernel_size': 3, 'stride': 2, 'padding': 1, 'groups':1},
        {'in_channels': round_filters(32, width_coefficient), 'out_channels': round_filters(16, width_coefficient), 'kernel_size': 3, 'stride': 1, 'expand_ratio': 6, 'se_ratio': 0.25, 'drop_connect_rate': None, 'num_layers': round_repeats(1, depth_coefficient)},
        {'in_channels': round_filters(16, width_coefficient), 'out_channels': round_filters(24, width_coefficient), 'kernel_size': 3, 'stride': 2, 'expand_ratio': 6, 'se_ratio': 0.25, 'drop_connect_rate': None, 'num_layers': round_repeats(2, depth_coefficient)},
        {'in_channels': round_filters(24, width_coefficient), 'out_channels': round_filters(40, width_coefficient), 'kernel_size': 3, 'stride': 2, 'expand_ratio': 6, 'se_ratio': 0.25, 'drop_connect_rate': None, 'num_layers': round_repeats(2, depth_coefficient)},
        {'in_channels': round_filters(40, width_coefficient), 'out_channels': round_filters(80, width_coefficient), 'kernel_size': 3, 'stride': 1, 'expand_ratio': 6, 'se_ratio': 0.25, 'drop_connect_rate': None, 'num_layers': round_repeats(3, depth_coefficient)},
        {'in_channels': round_filters(80, width_coefficient), 'out_channels': round_filters(112, width_coefficient), 'kernel_size': 3, 'stride': 2, 'expand_ratio': 6, 'se_ratio': 0.25, 'drop_connect_rate': None, 'num_layers': round_repeats(3, depth_coefficient)},
        {'in_channels': round_filters(112, width_coefficient), 'out_channels': round_filters(192, width_coefficient), 'kernel_size': 3, 'stride': 2, 'expand_ratio': 6, 'se_ratio': 0.25, 'drop_connect_rate': None, 'num_layers': round_repeats(4, depth_coefficient)},
        {'in_channels': round_filters(192, width_coefficient), 'out_channels': round_filters(320, width_coefficient), 'kernel_size': 3, 'stride': 1, 'expand_ratio': 6, 'se_ratio': 0.25, 'drop_connect_rate': None, 'num_layers': round_repeats(1, depth_coefficient)}
    ]
    model = EfficientNet(layer_params)
    return model

def round_filters(filters, width_coefficient=None):
    if not width_coefficient:
        return filters
    divisor = 8
    filters *= width_coefficient
    new_filters = int(filters + divisor / 2) // divisor * divisor
    if new_filters < 0.9 * filters:
        new_filters += divisor
    return int(new_filters)

def round_repeats(repeats, depth_coefficient=None):
    if not depth_coefficient:
        return repeats
    return int(math.ceil(depth_coefficient * repeats))
