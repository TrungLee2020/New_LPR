import torch
from PIL import Image
from hyperparams import Hyperparams as hp

def load_vocab():
    c2i = {char: idx for idx, char in enumerate(hp.alphabet)}
    i2c = {idx: char for idx, char in enumerate(hp.alphabet)}
    return c2i, i2c

def inverse_norm(image, mean, std):
    image = ((image * torch.tensor(std).reshape(image.size(0), 1, 1).to(image.device)) + torch.tensor(mean).reshape(image.size(0), 1, 1).to(image.device))
    return image

def drop_connect(inputs, p, training):
    if not training:
        return inputs
    batch_size = inputs.size(0)
    keep_prob = 1 - p
    random_tensor = keep_prob
    random_tensor += torch.rand([batch_size, 1, 1, 1], dtype=inputs.dtype, device=inputs.device)
    binary_tensor = torch.floor(random_tensor)
    output = inputs / keep_prob * binary_tensor
    return output

class Resize:
    def __call__(self, image):
        old_size = (image.width, image.height)
        factor_x = image.width / hp.size[0]
        factor_y = image.height / hp.size[1]
        factor = max(factor_x, factor_y)
        new_size = (min(hp.size[0], int(image.width / factor)), min(hp.size[1], int(image.height / factor)))
        image = image.resize(size=new_size)
        new_image = Image.new('RGB', hp.size, color=0)
        new_image.paste(image, ((hp.size[0]-new_size[0])//2, (hp.size[1]-new_size[1])//2))
    
        return new_image

class LabelEncoding:
    def __init__(self):
        self.c2i, _ = load_vocab()
    
    def __call__(self, label):
        encoded = [self.c2i[c] for c in list(label)]
        return encoded

class SEModule(torch.nn.Module):
    def __init__(self, in_channels, squeeze_channels, swish):
        super(SEModule, self).__init__()
        self.pool = torch.nn.AdaptiveAvgPool2d(1)
        self.se = torch.nn.Sequential(
            torch.nn.Linear(in_features=in_channels, out_features=squeeze_channels),
            swish,
            torch.nn.Linear(in_features=squeeze_channels, out_features=in_channels),
            torch.nn.Sigmoid()
        )
    def forward(self, x):
        b, c, _, _ = x.size()
        x_pool = self.pool(x).view(b, c) # (b, c)
        return x * self.se(x_pool).view(b, c, 1, 1)

class ConvBlock(torch.nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, stride, padding, groups, batch_norm=True, activation=True):
        super(ConvBlock, self).__init__()
        self.activation = activation
        self.batch_norm = batch_norm
        self.conv = torch.nn.Conv2d(in_channels=in_channels, out_channels=out_channels, kernel_size=kernel_size, stride=stride, padding=padding, groups=groups, dilation=1, bias=False)
        self.bn = torch.nn.BatchNorm2d(num_features=out_channels)
        self.act = torch.nn.LeakyReLU(0.1, inplace=True)

    def forward(self, x):
        x = self.conv(x)
        if self.batch_norm:
            x = self.bn(x)
        if self.activation:
            x = self.act(x)
        return x

class LayerNorm(torch.nn.Module):
    def __init__(self, norm_dim, eps=1e-5):
        super(LayerNorm, self).__init__()
        self.norm_dim = norm_dim
        self.eps = eps

    def forward(self, x):
        mean = x.mean(dim=self.norm_dim, keepdim=True)
        std = torch.square(x - mean).mean(dim=self.norm_dim, keepdim=True)
        return (x - mean) / torch.sqrt(std + self.eps)
