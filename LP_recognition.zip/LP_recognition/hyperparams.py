class Hyperparams:
    alphabet = [' ', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
                'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'J', 'K', 'L',
                'M', 'N', 'Q', 'S', 'T', '京', '宁', '沪', '津', '浙',
                '湘', '皖', '粤', '苏', '豫', '贵', '鄂', '鲁']
    size = (192, 64)
    max_sequence_length = 9
    n_jobs = 2
    epochs = 300
    batch_size = 5
    lr = 1.0
    update = 1
    display = 2

    mean = [0.485, 0.456, 0.406]
    std = [0.229, 0.224, 0.225]

    logdir = './model/'
    # logdir = '/content/drive/MyDrive/AI/CLP/Ver_1.0.0/model/'